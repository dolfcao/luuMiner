#ifndef OMASHA256_H
#define OMASHA256_H

void Sha256(unsigned char* in, unsigned char* out);

#endif
