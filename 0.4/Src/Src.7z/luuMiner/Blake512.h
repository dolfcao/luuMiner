#ifndef BLAKE512_H
#define BLAKE512_H

#include <stdint.h>
void blake512_hash(uint8_t *out, const uint8_t *in);

#endif
