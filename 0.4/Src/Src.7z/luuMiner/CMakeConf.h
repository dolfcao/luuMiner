#ifndef CMAKECONF_H
#define CMAKECONF_H

#define REAPER_VERSION "@REAPER_VERSION@"
//#define CPU_MINING_ONLY

#endif
